package org.example.exercicespring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciceSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExerciceSpringApplication.class, args);
    }

}
